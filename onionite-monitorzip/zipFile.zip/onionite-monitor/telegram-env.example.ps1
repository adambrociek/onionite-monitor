$env:TELEGRAM_BOT_TOKEN = "123456789:replace_with_your_bot_token"
$env:TELEGRAM_CHAT_ID = "123456789"
