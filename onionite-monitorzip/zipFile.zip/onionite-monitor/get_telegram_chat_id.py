from __future__ import annotations

import json
import os
import urllib.error
import urllib.request


def main() -> int:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        print("Set TELEGRAM_BOT_TOKEN first.")
        return 1

    url = f"https://api.telegram.org/bot{token}/getUpdates"
    try:
        with urllib.request.urlopen(url, timeout=15) as response:
            payload = json.loads(response.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        print(f"Telegram getUpdates failed: HTTP {exc.code} {exc.read().decode('utf-8', errors='replace')}")
        return 1

    updates = payload.get("result", [])
    if not updates:
        print("No updates found. Send any message to your bot in Telegram, then run this again.")
        return 1

    seen: set[str] = set()
    for update in updates:
        message = update.get("message") or update.get("channel_post") or {}
        chat = message.get("chat") or {}
        chat_id = chat.get("id")
        if chat_id is None or str(chat_id) in seen:
            continue
        seen.add(str(chat_id))
        title = chat.get("title") or chat.get("username") or chat.get("first_name") or "chat"
        print(f"{chat_id}  {title}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
